package collabee.jh.mvc;

import java.io.IOException;
import java.util.HashSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import collabee.jh.dao.ScheduleSaveDao;

public class InsertScheduleAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int writer_id = Integer.parseInt(request.getParameter("writer_id"));
		String title = request.getParameter("title");
		String start_date = request.getParameter("start_date");
		String finish_date = request.getParameter("finish_date");
		String attendee = request.getParameter("attendeeList");
		String locations = request.getParameter("locations");
		String content = request.getParameter("summary");
		int workspace_id = Integer.parseInt(request.getParameter("workspace_id"));

		try {
			ScheduleSaveDao dao = new ScheduleSaveDao();
			dao.setSchedule(workspace_id, writer_id, title, content, locations, start_date, finish_date, attendee);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
