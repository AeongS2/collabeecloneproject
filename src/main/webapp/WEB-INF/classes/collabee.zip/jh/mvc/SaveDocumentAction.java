package collabee.jh.mvc;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import collabee.jh.dao.DocumentSaveDao;

public class SaveDocumentAction implements Action{//문서 저장

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		
		System.out.println("title : "+ title);
		System.out.println("content : " + content);
		content = content.replaceAll("Editor.js", "EDITOR.YG");
		System.out.println("content : " + content);

		String time = "";
		JSONArray blocks = new JSONArray();//String으로 받은 data jsonArray로 만듬
		try {
			JSONParser parser = new JSONParser();//parsing:분석
			JSONObject jsonObj = (JSONObject) parser.parse( content );
			time = jsonObj.get("time") + "";    // String.valueOf(34) ----> "34"
			blocks = (JSONArray)jsonObj.get("blocks");
		} catch(Exception e) { e.printStackTrace(); }
		
		response.setContentType("application/json");
		JSONObject objRet = new JSONObject();
		objRet.put("new_content",content);
		
		PrintWriter out = response.getWriter();
		out.println(objRet);
		
/*//parsing하기
System.out.println("So, time = " + time);
System.out.println("blocks(JSONArray) = " + blocks.toString());
for(int i=0; i<=blocks.size()-1; i++) {
	System.out.println("[" + i + "] : ");
	JSONObject obj = (JSONObject)blocks.get(i);
	JSONObject data = (JSONObject)obj.get("data");
	String id = (String)obj.get("id");
	String type = (String)obj.get("type");
	System.out.println("\tdata = " + data);
	System.out.println("\tid = " + id);
	System.out.println("\ttype = " + type);
}
*/

//		int workspace_id = Integer.parseInt(request.getParameter("workspace_id"));
//		int member_id = Integer.parseInt(request.getParameter("loginId"));
//		int document_id = Integer.parseInt(request.getParameter("document_id"));
		
		DocumentSaveDao dao = new DocumentSaveDao();
		try {
//			dao.saveDocument(title, content, workspace_id, member_id, document_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
//		request.getRequestDispatcher("Controller?command=savedDocument").forward(request, response);
		
		
		
	}

}
