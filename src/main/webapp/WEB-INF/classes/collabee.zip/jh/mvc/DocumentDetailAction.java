package collabee.jh.mvc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DocumentDetailAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int document_id = Integer.parseInt(request.getParameter("document_id"));
		
		//발행된 문서 보기
		
		
		request.getRequestDispatcher("../PostedDocument.jsp").forward(request, response);
		
	}
	
}
