package collabee.jh.mvc;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import collabee.jh.dao.myWorkspaceScheduleDao;
import collabee.jh.dto.MyScheduleDto;

public class TwoScheduleAction implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int workspace_id = Integer.parseInt(request.getParameter("workspace_id"));
		
		ArrayList<MyScheduleDto> list = new ArrayList<MyScheduleDto>();
		myWorkspaceScheduleDao dao = new myWorkspaceScheduleDao();
		list = dao.getCalender(workspace_id);
		
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/json");
		PrintWriter out = response.getWriter();
		
		JSONArray array = new JSONArray();
		for(int i = 0; i <=1; i++) {
			JSONObject obj = new JSONObject();
			obj.put("start_date", list.get(i).getStart_date());
			obj.put("finish_date", list.get(i).getFinish_date());
			obj.put("title", list.get(i).getTitle());
			obj.put("member_id", list.get(i).getMember_id());//작성자
			array.add(obj);
		}
		out.print(array);
	}

}
