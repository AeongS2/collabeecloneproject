package collabee.jh.mvc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import collabee.jh.dao.WorkspaceUpdateInfo2Dao;

public class WorkspaceUpdate2Action implements Action{

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int workspace_id = Integer.parseInt(request.getParameter("workspace_id"));
		int confidential = Integer.parseInt(request.getParameter("confidential"));
		int complete = Integer.parseInt(request.getParameter("complete"));
		
		WorkspaceUpdateInfo2Dao dao = new WorkspaceUpdateInfo2Dao();
		dao.setWorkspace_Confidential(confidential, workspace_id);
		dao.setWorkspace_Complete(complete, workspace_id);
		
		
	}

}
