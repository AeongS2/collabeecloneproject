package collabee.jh.mvc;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import collabee.jh.dao.DocumentPostDao;
import collabee.jh.dao.RtDocumentIdDao;

public class PostDocumentAction implements Action{ //문서작성클릭

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int member_id = Integer.parseInt(request.getParameter("loginId"));
		
		int document_id = 0;
		DocumentPostDao dao = new DocumentPostDao();//문서작성클릭, 임시저장
		RtDocumentIdDao rdao = new RtDocumentIdDao();//문서id
		try {
			dao.setDocument(title, content, member_id);
			document_id = rdao.getDocument_id(1, member_id);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("document_id", document_id);//문서id저장. 임시저장리스트에 attr
		//request.getRequestDispatcher("Controller?command=postingDocument");
		//저장하고 끝? 다른데 안가도 되나?
		
	}

}
