package collabee.jh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import collabee.jh.dto.ScheduleDto;
//import collabee.jh.dto.ScheduleIdDto;

//일정테이블 전체 출력
public class ScheduleDao {
	ArrayList<ScheduleDto> getSchedule(int schedule_id) {
		Connection conn = DBConnection.getConnection();
		ArrayList<ScheduleDto> list = new ArrayList<ScheduleDto>();
		String sql="SELECT * FROM simple_board WHERE schedule_id = ?";
		try {
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, schedule_id);
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			int scheduleId = rs.getInt(1);
			int workspace_id = rs.getInt(2);
			int writer_id = rs.getInt(3);
			String title = rs.getString(4);
			String content = rs.getString(5);
			int document_id = rs.getInt(6);
			String start_date = rs.getString(7);
			String finish_date = rs.getString(8);
			String locations = rs.getString(9);
			String creation_date = rs.getString(10);
			String edit_date = rs.getString(11);
			String reader = rs.getString(12);
			int drafts = rs.getInt(13);
			String attendee = rs.getString(14);
			
			ScheduleDto dto = new ScheduleDto(scheduleId, workspace_id, writer_id, title, content, document_id, start_date, finish_date, locations, creation_date, edit_date, reader, drafts, attendee);
			list.add(dto);	
		}

		} catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
