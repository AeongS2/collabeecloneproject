package collabee.jh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import collabee.jh.dto.DocumentDto;

public class ShowDocumentDao {//detail
	//문서 출력 
	
	/*SELECT d.title, d.content, b.bookmark_id, a.document_id 
FROM document d, bookmark b, document_alarm a
WHERE d.document_id = 20 and d.writer_id = 2 and a.document_id = d.document_id;
	 * 
	 * 
	 */
	public ArrayList<DocumentDto> showDocument(int document_id) throws Exception {
		//제목과 내용, 문서알림,북마크 / 문서에 연결된 일정, 할일, 의결  / 협업공간과 협업공간 칸반리스트 
		ArrayList<DocumentDto> list = new ArrayList<DocumentDto>();
		String sql = "SELECT title, content FROM document WHERE document_id = ?";
		Connection conn = DBConnection.getConnection();
		try {			
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, document_id);//보고있는문서id
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				String title = rs.getString("title");
				String content = rs.getString("content");
				
				DocumentDto dto = new DocumentDto(title, content );
				list.add(dto);
			}
			rs.close();
			pstmt.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		return list;
	}
}
