package collabee.jh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Map;

import collabee.jh.dto.ScheduleSaveDto;

public class ScheduleSaveDao {
	//일정저장(클릭)
	public void setSchedule(int workspace_id, int writer_id, String title, String content, String locations, String start_date, String finish_date, String attendee) {
		String sql = "INSERT INTO schedule (schedule_id, workspace_id, writer_id, title, content, locations, reader, start_date, finish_date, attendee)VALUES (schedule_id.nextval, ?, ?, ?, ?, ?, ?, ?, ?, ?)"; 
		try {
			Connection conn = DBConnection.getConnection();
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, workspace_id);
			pstmt.setInt(2, writer_id);//작성자id
			pstmt.setString(3, title);
			pstmt.setString(4, content);
			pstmt.setString(5, locations);
			pstmt.setString(6, writer_id + "_");//저장하면 바로 읽게됨
			pstmt.setString(7, start_date);
			pstmt.setString(8, finish_date);
			pstmt.setString(9, attendee);//참석자id
			pstmt.executeUpdate();//변경된 행의 수
			DBConnection.pstmtClose(pstmt);
		} catch (SQLException e) {
			e.printStackTrace();
		}//일정 drafts 없앰
	}
}
