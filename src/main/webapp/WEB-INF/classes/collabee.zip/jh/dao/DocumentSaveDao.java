package collabee.jh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DocumentSaveDao {
	//문서 저장 클릭시
	public void saveDocument(String title, String content, int workspace_id, int member_id, int document_id) throws Exception {
		//임시저장 바꾸기
		if(title == null & content == null) {
			//System.out.println("내용을 입력해 주세요.");
		}
		Connection conn = DBConnection.getConnection();
		String sql = "UPDATE document SET drafts = 0, reader = ? WHERE document_id = ?";
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setString(1, member_id + "_");//로그인한 id
		pstmt.setInt(2, document_id);//보고있는문서id
		DBConnection.pstmtClose(pstmt);
	}
}
