package collabee.jh.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class DocumentPostDao {
	//문서작성 클릭  but, 아무것도 안쓰면 임시저장 안됨.  근데 이거는 에디터 쓰면 어케될지 몰겟음
	public void setDocument(String title, String content, int member_id) throws Exception {
		String sql = "INSERT INTO document (document_id, writer_id, title, content, edit_date, drafts) "
				+ "VALUES (document_id.nextval, ?, ?, ?, SYSDATE, 1)"; 
		
		Connection conn = DBConnection.getConnection();
		PreparedStatement pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, member_id); //로그인한 id
		if(title == null & content != null) {
			pstmt.setString(2, content);
		} else if(title != null & content == null){
			pstmt.setString(2, title);
		}
		pstmt.setString(3, content);
		if(title != null || content != null) {
			pstmt.executeUpdate();
		} else {
			return;
		}
		DBConnection.pstmtClose(pstmt);
	}
}
