package collabee.jh.ajax;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

import collabee.jh.dao.DBConnection;
import collabee.jh.dao.WorkspacePostListDao;
import collabee.jh.dto.WorkspacePostListDto;


@WebServlet("/WorkspaceOrderDao")
public class WorkspaceOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("order");
		ArrayList<WorkspacePostListDto> list = new ArrayList<WorkspacePostListDto>();
		int workspace_id = Integer.parseInt(request.getParameter("workspaceId"));
		int fl = Integer.parseInt(request.getParameter("fl"));
		try {
			Connection conn = DBConnection.getConnection();
			WorkspacePostListDao dao = new WorkspacePostListDao();
			list = dao.getDocument_List(workspace_id/*, fl*/);
		}catch(Exception e) {
			e.printStackTrace();
		}
			
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out = response.getWriter();
		
		JSONArray array = new JSONArray();
		for(WorkspacePostListDto dto : list) {
			JSONObject obj = new JSONObject();
			obj.put("name", dto.getName());
			obj.put("kanban_icon_p", dto.getKanban_icon_p());
			obj.put("title", dto.getTitle());
			obj.put("date", dto.getDate());
			array.add(obj);
		}
		out.print(array);	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}

}
