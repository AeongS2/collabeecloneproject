package com.one.dto;

public class GetDocumentDraftsDto {
	private String title;
	private String content;
	private int workspace_id;
	//private String 
	
	
}
