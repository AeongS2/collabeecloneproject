package com.one.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MemberIdentifiedDao {
	public boolean MemberPwIdentified(String pw, int member_id) {
		String sql = "SELECT count(*) cnt FROM member WHERE member_id = ? and pw = ?";
		Connection conn = DBConnection.getConnection();
		boolean bln = false;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, member_id);
			pstmt.setString(2, pw);
			ResultSet rs = pstmt.executeQuery();
			if(rs.next()) {
				if(rs.getInt("cnt")==1) {
					bln = true;
				}
			}
			DBConnection.getClose(pstmt, rs);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bln;
	}
}
