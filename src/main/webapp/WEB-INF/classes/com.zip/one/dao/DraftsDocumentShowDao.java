package com.one.dao;

public class DraftsDocumentShowDao {
	/*
	 * public ArryaList<GetDocumentDraftsDto> getDocumentDrafts(int document_id){
	 * 
	 * }
	 */
	
	
}
