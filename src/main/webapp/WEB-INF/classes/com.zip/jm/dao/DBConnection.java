package com.jm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBConnection {

	private static Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	public static Connection getConnection() {
		if( conn != null ) {
			return conn;
		} else {
			String driver = "oracle.jdbc.driver.OracleDriver";
			String url = "jdbc:oracle:thin:@192.168.1.7:1521:xe";
			//192.168.1.7 학원	//192.168.219.102
			String dbID = "oraclePort";
			String dbPW = "369369";
			
			try {
				Class.forName(driver);
				conn = DriverManager.getConnection(url, dbID, dbPW);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return conn;
		}
		
	}
}
